function PerdLbeta=VecPer(dLbeta,sigma,C,B)
    beta=1;
    [r,c]=size(dLbeta);
    AngGrad=zeros(r-1,c);
    RadGrad=zeros(1,c);

    parfor i=1:c
        [RadGrad(i), AngGrad(:,i)]=cartesian_to_hyperspherical(dLbeta(:,i));
    end
    C_Ang=sqrt(r+2)*beta*pi;
    PerRad=RadGrad+(sigma.*C).*randn(1,c)/B;
    PerAng=AngGrad+C_Ang.*sigma.*randn(r-1,c)/B;
    Ang1=PerAng(1:r-2,:);
    Ang1(Ang1<=0)=0;
    Ang1(Ang1>pi)=pi;
    Ang2=PerAng(r-1,:);
    Ang2(Ang2>=pi)=pi;
    Ang2(Ang2<=-pi)=-pi;
    PerAng=[Ang1;Ang2];

    PerdLbeta=zeros(r,c);
    parfor i=1:c
        PerdLbeta(:,i)=hyperspherical_to_cartesian(PerRad(i), PerAng(:,i));
    end
end