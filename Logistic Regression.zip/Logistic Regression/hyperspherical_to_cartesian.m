function coords = hyperspherical_to_cartesian(radius, angles)
    n = numel(angles) + 1;
    coords = zeros(n, 1);
    
    coords(1) = radius * cos(angles(1));
    for i = 2:n-1
        coords(i) = radius * prod(sin(angles(1:i-1))) * cos(angles(i));
    end
    coords(n) = radius * prod(sin(angles));
end