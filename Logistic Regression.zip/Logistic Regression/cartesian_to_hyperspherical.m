% function [radius, angles] = cartesian_to_hyperspherical(coords)
%     n = numel(coords);
%     angles = zeros(n-1, 1);
%     radius = norm(coords);
%     
%     for i = 1:n-2
%         angles(i) = acos(coords(i) / norm(coords(i:n)));
%     end
%     angles(n-1) = 2*(pi/2 - atan((coords(n-1)+norm(coords(n-1:n)))/coords(n)));
% end

function [radius, angles] = cartesian_to_hyperspherical(coords)
    n = numel(coords);
    angles = zeros(n-1, 1);
    radius = norm(coords);
    
    for i = 1:n-2
        angles(i) = atan2(norm(coords(i+1:n)),coords(i));
    end
    angles(n-1) = atan2(coords(n),coords(n-1));
end