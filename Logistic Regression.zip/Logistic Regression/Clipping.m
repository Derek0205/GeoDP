function ClippedGradient=Clipping(OrgGradient,C) %OrgGradient must be a vector,C is the clipping theoreshold
    L2=norm(OrgGradient)/C;
    if L2>1
        ClippedGradient=OrgGradient./L2;
    else
        ClippedGradient=OrgGradient;
    end
end

%To prevent clipping exposure and excessive noise, this function bounds the
%range of each dimension of the gradient.