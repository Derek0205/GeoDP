function PerdLbeta=NumPer(dLbeta,sigma,C,B)%非向量化加噪
    [r,c]=size(dLbeta);
    parfor j=1:c
        if norm(dLbeta(:,j))>C
           dLbeta(:,j)=dLbeta(:,j)/(norm(dLbeta(:,j))/C);
        end
    end
    Noise=(sigma.*C).*randn(r,c)/B;
    PerdLbeta=dLbeta+Noise;
end